const Cart = require('../models/Cart');
const Product = require('../models/Product');

// Add a product to the cart
exports.addToCart = async (req, res, next) => {
  const { productId, quantity } = req.body;
  try {
    const product = await Product.findById(productId);
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    const cartItem = await Cart.findOne({ productId });
    if (cartItem) {
      // Update quantity if item already in cart
      cartItem.quantity += quantity;
      await cartItem.save();
      return res.status(200).json(cartItem);
    }

    // Create a new cart item
    const newCartItem = new Cart({ productId, quantity });
    const savedCartItem = await newCartItem.save();
    res.status(201).json(savedCartItem);
  } catch (err) {
    next(err);
  }
};

// Get all items in the cart
exports.getCartItems = async (req, res, next) => {
  try {
    const cartItems = await Cart.find().populate('productId', 'name price');
    res.status(200).json(cartItems);
  } catch (err) {
    next(err);
  }
};

// Update quantity of a product in the cart
exports.updateCartItem = async (req, res, next) => {
  const { quantity } = req.body;
  try {
    const cartItem = await Cart.findById(req.params.id);
    if (!cartItem) {
      return res.status(404).json({ message: 'Cart item not found' });
    }

    cartItem.quantity = quantity;
    await cartItem.save();
    res.status(200).json(cartItem);
  } catch (err) {
    next(err);
  }
};

// Remove a product from the cart
exports.deleteCartItem = async (req, res, next) => {
  try {
    const cartItem = await Cart.findByIdAndDelete(req.params.id);
    if (!cartItem) {
      return res.status(404).json({ message: 'Cart item not found' });
    }
    res.status(200).json({ message: 'Cart item deleted successfully' });
  } catch (err) {
    next(err);
  }
};
