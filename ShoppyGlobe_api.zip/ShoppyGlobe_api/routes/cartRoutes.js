const express = require('express');
const {
  addToCart,
  getCartItems,
  updateCartItem,
  deleteCartItem,
} = require('../controllers/cartController');
const { protect } = require('../middlewares/authMiddleware');
const router = express.Router();

router.route('/').get(protect, getCartItems).post(protect, addToCart);
router
  .route('/:id')
  .put(protect, updateCartItem)
  .delete(protect, deleteCartItem);

module.exports = router;
